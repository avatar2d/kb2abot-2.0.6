module.exports = {
	Apprentice: require('./Apprentice'),
	Bodyguard: require('./Bodyguard'),
	Cupid: require('./Cupid'),
	Evilseer: require('./Evilseer'),
	Fruitbrute: require('./Fruitbrute'),
	Goodseer: require('./Goodseer'),
	Hunter: require('./Hunter'),
	Investigator: require('./Investigator'),
	Lycan: require('./Lycan'),
	Oldman: require('./Oldman'),
	Tanner: require('./Tanner'),
	Villager: require('./Villager'),
	Werewolf: require('./Werewolf'),
	Witch: require('./Witch')
};
